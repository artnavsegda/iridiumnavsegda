// Hee is the RUSSIAN LANGUAGE for date and day on the Main page
// you can make your own translation (see below)

// TO USE: delete /* and */ symbols that used to turn script OFF

/*
IR.AddListener(IR.EVENT_START,0,function()
{
   var item = IR.GetItem("_Photo").GetItem("Item 1"); // item with date
   var itemD = IR.GetItem("_Photo").GetItem("Item 3"); // item with day of week
   
   var month = IR.GetVariable("System.Date.Month");    
   var dayofweek = IR.GetVariable("System.Date.DayOfWeek");
   
   function set_month(cur_month)
   {
      item.Text = IR.GetVariable("System.Date.Day")+" "+cur_month+" "+IR.GetVariable("System.Date.Year");
   }
   function set_dayofweek(day)
   {
      itemD.Text = day;
   }  

   switch(month)
   {
      case 1: set_month("января");     break;
      case 2: set_month("февраля");    break;
      case 3: set_month("марта");      break;
      case 4: set_month("апреля");     break;
      case 5: set_month("мая");        break;
      case 6: set_month("июня");       break;
      case 7: set_month("июля");       break;
      case 8: set_month("августа");    break;
      case 9: set_month("сентября");   break;
      case 10: set_month("октября");    break;
      case 11: set_month("ноября");     break;
      case 12: set_month("декабря");    break;         
   }  
   
   switch(dayofweek)
   {      
      case 0: set_dayofweek("воскресенье");   break; 
      case 1: set_dayofweek("понедельник");   break; 
      case 2: set_dayofweek("вторник");       break; 
      case 3: set_dayofweek("среда");         break; 
      case 4: set_dayofweek("четверг");       break; 
      case 5: set_dayofweek("пятница");       break; 
      case 6: set_dayofweek("суббота");       break; 
   }
});

*/

